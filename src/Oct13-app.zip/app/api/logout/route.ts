import { NextResponse } from "next/server";
import { adminCookieName, adminCookieOptions } from "@/app/lib/admin-auth";

export async function POST() {
  const response = NextResponse.json({ ok: true });
  response.cookies.set(adminCookieName, "", adminCookieOptions(0));
  return response;
}
